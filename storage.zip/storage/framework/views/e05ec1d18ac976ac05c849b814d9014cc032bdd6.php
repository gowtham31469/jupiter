
<?php echo $__env->make('layouts.Admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          
