 <!-- left-sidebar-1 -->
            <div class="left-sidebar left-sidebar-1">
                <div class="wrapper">
                    <div class="content">
                        <!-- end sidebar-heading-1 -->
                        <!-- section -->
                        <div class="section">
                            <!-- end section-title -->
                            <!-- menu -->
                            <ul class="list-unstyled">
                                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                           <a href="#" onclick="<?php echo e($mod->url_path); ?>" class="btn btn-default btn-flat btn-sidebar btn-sidebar-1">
                                            <i class="<?php echo e($mod->image); ?>"></i>
                                            <span class="title"><?php echo e($mod->module_name); ?></span>
                                            </a>
                                        </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <!-- end menu -->
                        </div>
                        <!-- end sidebar-widget-2 -->
                    </div>
                </div>
            </div>
            <!-- end left-sidebar-1 -->
