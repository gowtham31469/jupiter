<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-success">
                <div class="panel-heading">Merchandiser's Dashboard</div>

                <div class="panel-body">
                    Greetings.. Merchandiser
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('merchandiser.layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>