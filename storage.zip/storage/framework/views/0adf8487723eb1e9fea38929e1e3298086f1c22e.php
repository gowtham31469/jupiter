<?php $__env->startSection('content'); ?>
<div class="container-fluid">
        <div class="row">
            <div class="login-section">
                <div class="container">
                    <div class="login-card card-container">
                        <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
                        <img id="profile-img" class="profile-img-card" src="<?php echo e(asset('images/logo.png')); ?>" />
                    
                       <form class="form-group" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php if($errors->has('email')): ?>
                            <span class="help-block" style="color:red">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                            <?php endif; ?>
                            <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>
                            <span id="reauth-email" class="reauth-email"></span>
                            <input id="email" type="email" class="form-control" placeholder="Email address" required autofocus name="email" value="<?php echo e(old('email')); ?>">
                           <input id="password" type="password" class="form-control" name="password" required placeholder="Password">
                            <div id="remember" class="checkbox">
                                <label>
                       <input type="checkbox" class="custom-control-input" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember me
                    </label>
                            </div>
                            <button class="btn btn-sm btn-primary btn-block " type="submit">Sign in</button>
                        </form>
                        <!-- /form -->
                        <a href="#" class="forgot-password">
                Forgot the password?
            </a>
                    </div>
                    <!-- /card-container -->
                </div>
                <p class="text-center terms">By clicking on SIGNIN you will be agreeing all the terms and conditions.</p>
                <!-- /container -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>