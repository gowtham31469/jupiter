 <?php if(Auth::guard("web")->user()): ?> <?php $__env->startSection('content'); ?>

<body id="pages-empty-page" data-layout="top-navigation-1" data-background="light" data-sidebar="light" data-navbar="custom" data-top-navigation="dark" data-controller="pages" data-view="empty-page" data-collapsed="false" data-fullscreen="false" data-logo="dark" class="pace-done">
    <div id="fakeloader"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="left-sidebar-placeholder"></div>

            <div class="col main">
       
                <!-- jumbotron-1 -->
                <div class="jumbotron jumbotron-1">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col">
                                <ol class="breadcrumb icon-angle-right">
                                    <li><a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
                                    </li>
                                    <li class="active">Sticker Orders</li>
                                </ol>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <a class="btn btn-info btn-rounded btn-icon" href="#">
                                    <i class="fa fa-plus"></i>
                                    <span class="btn-text">Create Order</span>
                                </a>
                                <h4>Order Management</h4>
                                <h5>Sticker Orders</h5>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end jumbotron-1 -->
                <div class="page">
                    <!-- pages/empty-page -->
                    <div class="row">
                        <div class="col">
                            <div class="widget">
                                <div class="row">
                                    <div class="col">
                                        <table id="datatable-example-2" class="table table-hover table-striped table-bordered" style="width: 100%">
                                            <thead>
                                                <tr>
                                                    <th>UVC</th>
                                                    <th>Purchase Order</th>
                                                    <th>Supplier Name</th>
                                                    <th>Theme</th>
                                                    <th>Order Qty</th>
                                                    <th>Type</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="<?php echo e($value->id); ?>">
                                                    <td><?php echo e($value->UVC); ?></td>
                                                    <td><?php echo e($value->BuyerPONo); ?></td>
                                                    <td><?php echo e($value->SupplierName); ?></td>
                                                    <td><?php echo e($value->Theme); ?></td>
                                                    <td><?php echo e($value->Quantity); ?></td>
                                                    <td><?php echo e($value->IsSTD == 0 ? "Solid":"Standard"); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end pages/empty-page -->
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?> <?php else: ?>
    <script type="text/javascript">
        window.location = "<?php echo e(url('/admin')); ?>";
    </script>
    <?php endif; ?> <?php $__env->startSection('jqueryIncludes'); ?>
    <script>
        $('#datatable-example-2').DataTable();
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.Admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>