<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <a class="navbar-brand" href="#"><img src="<?php echo e(asset('images/logo.png')); ?>"></a>
<!--            Jupiter Garments Accessories-->
        </div>
        <div id="navbar" class="navbar-collapse collapse" aria-expanded="false" style="height: 1px;">
            <ul class="nav navbar-nav hidden-md hidden-lg hidden-sm">
                 <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($mod->parent_id == 0): ?>
    
                 <li class="parent-menu"><a class="" href="<?php echo e($mod->url_path); ?>"><i class="<?php echo e($mod->image); ?>"></i><?php echo e($mod->module_name); ?></a></li>
                 <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <ul class="nav navbar-nav navbar-right">

                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="ion-person"></i> <?php echo e(Auth::user()->name); ?><span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="#">Profile</a></li>
                        <li><a href="#">Settings</a></li>
                        <li role="separator" class="divider"></li>
                        <li> <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a></li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">

                            <?php echo e(csrf_field()); ?>


                        </form>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="top-navigation hidden-xs hidden-sm">
    <ul class="nav-list ">
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($mod->parent_id == 0): ?>
        <li class="parent-menu"><a class="" href="<?php echo e($mod->url_path); ?>"><i class="<?php echo e($mod->image); ?>"></i><?php echo e($mod->module_name); ?></a></li>
        <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>