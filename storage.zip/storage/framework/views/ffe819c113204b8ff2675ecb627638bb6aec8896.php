<?php $__env->startSection('content'); ?>
 
            <div class="col-sm-12 col-md-12 main">
               
                <h2 style="text-align:center">Coming Soon ...!</h2>

            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.Admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>